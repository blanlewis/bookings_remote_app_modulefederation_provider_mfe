import './ProviderComponent.css';
declare const Bookings: () => import("react").JSX.Element;
export default Bookings;
